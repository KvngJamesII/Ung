import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

type FundWalletModalProps = {
  onClose: () => void;
};

const FUND_AMOUNTS = ['₦600', '₦1100', '₦1600', '₦2100', '₦3100', '₦5100'];

export default function FundWalletModal({ onClose }: FundWalletModalProps) {
  const [step, setStep] = useState(1);
  const [selectedAmount, setSelectedAmount] = useState('');
  const [paymentName, setPaymentName] = useState('');
  const [email, setEmail] = useState('');
  const [paymentReceipt, setPaymentReceipt] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const emailInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const fundWalletMutation = useMutation({
    mutationFn: async () => {
      try {
        const amount = parseInt(selectedAmount.replace('₦', ''));
        
        // Create a new FormData instance
        const formData = new FormData();
        formData.append('amount', amount.toString());
        formData.append('paymentName', paymentName);
        formData.append('email', email);
        
        // Only append file if it exists
        if (paymentReceipt) {
          formData.append('paymentReceipt', paymentReceipt);
        }
        
        console.log('Sending deposit request with:', {
          amount: amount.toString(),
          paymentName,
          hasFile: paymentReceipt !== null
        });
        
        // Use fetch directly for FormData with files
        const response = await fetch('/api/deposits', {
          method: 'POST',
          body: formData,
          // No authentication needed
          // Do NOT set Content-Type when sending FormData with files
          // The browser will set it with the correct boundary
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('Deposit request failed:', {
            status: response.status,
            statusText: response.statusText,
            errorText
          });
          throw new Error(errorText || response.statusText);
        }
        
        return response.json();
      } catch (error) {
        console.error('Error in fundWalletMutation:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      toast({
        title: "Payment verification initiated",
        description: "We're verifying your payment. You'll be notified once it's approved.",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit payment",
        description: error.message || "There was an error submitting your payment.",
        variant: "destructive",
      });
    },
  });

  const handleSelectAmount = (amount: string) => {
    setSelectedAmount(amount);
    setStep(2);
  };
  
  const handlePaymentMade = () => {
    setStep(3);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPaymentReceipt(file);
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmitProof = () => {
    if (!email.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide your email address.",
        variant: "destructive",
      });
      return;
    }
    
    if (!paymentName.trim() && !paymentReceipt) {
      toast({
        title: "Missing information",
        description: "Please provide either the name used for transfer or upload a receipt.",
        variant: "destructive",
      });
      return;
    }
    
    // Log what we're sending
    console.log('Submitting payment proof:', {
      amount: selectedAmount,
      paymentName,
      paymentReceipt: paymentReceipt ? {
        name: paymentReceipt.name,
        size: paymentReceipt.size,
        type: paymentReceipt.type
      } : null
    });
    
    fundWalletMutation.mutate();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-neutral-800 rounded-xl w-full max-w-md p-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Fund Wallet</h2>
          <button onClick={onClose} className="text-gray-400">
            <X size={20} />
          </button>
        </div>
        
        {/* Step 1: Select Amount */}
        {step === 1 && (
          <div>
            <p className="text-center mb-4">Select the amount you want to deposit</p>
            
            <div className="grid grid-cols-3 gap-3 mb-4">
              {FUND_AMOUNTS.map((amount) => (
                <button
                  key={amount}
                  onClick={() => handleSelectAmount(amount)}
                  className="bg-neutral-700 hover:bg-neutral-600 py-3 rounded-lg text-center"
                >
                  {amount}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* Step 2: Payment Details */}
        {step === 2 && (
          <div>
            <p className="text-center mb-2">
              Make a payment of <span className="font-bold">{selectedAmount}</span> into the bank below 👇
            </p>
            
            <div className="bg-neutral-700 p-4 rounded-lg mb-4 text-center">
              <p className="mb-1">✅ 1006897571</p>
              <p className="mb-1">🏦 LOTUS BANK</p>
              <p>👤 ADEDAYO</p>
            </div>
            
            <p className="text-sm text-center text-gray-400 mb-4">
              Kindly note, a service fee of ₦100 will be deducted
            </p>
            
            <Button 
              onClick={handlePaymentMade} 
              className="w-full bg-gradient-to-r from-[#8A2387] via-[#E94057] to-[#F27121] hover:opacity-90 text-white font-semibold py-3 px-4 rounded-lg transition-all"
            >
              I've made payment
            </Button>
          </div>
        )}
        
        {/* Step 3: Payment Proof */}
        {step === 3 && (
          <div>
            <p className="text-center mb-4">Please provide proof of payment</p>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 rounded-lg bg-neutral-700 border-neutral-600"
                placeholder="Enter your email address"
                required
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Name used for transfer</label>
              <Input
                type="text"
                value={paymentName}
                onChange={(e) => setPaymentName(e.target.value)}
                className="w-full p-3 rounded-lg bg-neutral-700 border-neutral-600"
                placeholder="Enter the name you used"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Upload receipt (optional)</label>
              <div className="bg-neutral-700 border border-dashed border-neutral-600 rounded-lg p-4 text-center">
                {previewUrl && (
                  <div className="mb-3">
                    <img src={previewUrl} alt="Receipt preview" className="max-h-40 mx-auto" />
                  </div>
                )}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-gradient-to-r from-[#8A2387] via-[#E94057] to-[#F27121] text-white font-medium py-2 px-4 rounded-lg inline-block"
                >
                  Upload Image
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>
            </div>
            
            <Button 
              onClick={handleSubmitProof}
              disabled={fundWalletMutation.isPending}
              className="w-full bg-gradient-to-r from-[#8A2387] via-[#E94057] to-[#F27121] hover:opacity-90 text-white font-semibold py-3 px-4 rounded-lg transition-all"
            >
              {fundWalletMutation.isPending ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  <span>Submitting...</span>
                </div>
              ) : (
                "✅ Done"
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
