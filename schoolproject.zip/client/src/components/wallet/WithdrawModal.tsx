import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

type WithdrawModalProps = {
  onClose: () => void;
};

const WITHDRAW_AMOUNTS = ['₦100', '₦200', '₦500', '₦1000', '₦1500', '₦2000'];
const NETWORKS = ['Airtel', 'MTN', 'Glo', '9mobile'];

const withdrawSchema = z.object({
  amount: z.string().min(1, "Please select an amount"),
  network: z.string().min(1, "Please select a network"),
  phoneNumber: z.string().length(11, "Phone number must be 11 digits").regex(/^\d+$/, "Phone number must contain only digits"),
});

type WithdrawFormValues = z.infer<typeof withdrawSchema>;

export default function WithdrawModal({ onClose }: WithdrawModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: user } = useQuery<any>({
    queryKey: ["/api/users/me"],
  });
  
  const form = useForm<WithdrawFormValues>({
    resolver: zodResolver(withdrawSchema),
    defaultValues: {
      amount: "",
      network: "",
      phoneNumber: "",
    },
  });
  
  const withdrawalMutation = useMutation({
    mutationFn: (values: WithdrawFormValues) => {
      const amount = parseInt(values.amount.replace('₦', ''));
      return apiRequest("POST", "/api/withdrawals", {
        amount,
        network: values.network,
        phoneNumber: values.phoneNumber,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal is processing. You'll be notified once it's completed.",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal failed",
        description: error.message || "There was an error processing your withdrawal.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: WithdrawFormValues) => {
    const amount = parseInt(values.amount.replace('₦', ''));
    
    // Check if user has enough balance
    if (user && user.withdrawableBalance < amount) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough balance to withdraw this amount.",
        variant: "destructive",
      });
      return;
    }
    
    withdrawalMutation.mutate(values);
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-neutral-800 rounded-xl w-full max-w-md p-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Withdraw Funds</h2>
          <button onClick={onClose} className="text-gray-400">
            <X size={20} />
          </button>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <p className="text-center mb-4">Select the amount you want to withdraw</p>
              
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <div className="grid grid-cols-3 gap-3 mb-2">
                      {WITHDRAW_AMOUNTS.map((amount) => (
                        <Button
                          key={amount}
                          type="button"
                          variant="outline"
                          className={`bg-neutral-700 hover:bg-neutral-600 py-3 border-0 ${
                            field.value === amount ? 'bg-gradient-to-r from-[#8A2387] via-[#E94057] to-[#F27121] text-white' : ''
                          }`}
                          onClick={() => field.onChange(amount)}
                        >
                          {amount}
                        </Button>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="network"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Network</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full bg-neutral-700 border-neutral-600">
                        <SelectValue placeholder="Select network" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-neutral-700">
                      {NETWORKS.map((network) => (
                        <SelectItem key={network} value={network}>
                          {network}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phoneNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input
                      type="tel"
                      maxLength={11}
                      className="w-full p-3 rounded-lg bg-neutral-700 border-neutral-600"
                      placeholder="Enter 11 digits phone number"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="bg-neutral-700 p-3 rounded-lg mb-4">
              <p className="font-medium">
                Amount to withdraw: <span>{form.watch("amount") || "₦0"}</span>
              </p>
              <p className="text-xs text-gray-400">Will be sent to your provided phone number</p>
            </div>
            
            <Button 
              type="submit" 
              disabled={withdrawalMutation.isPending}
              className="w-full bg-gradient-to-r from-[#8A2387] via-[#E94057] to-[#F27121] hover:opacity-90 text-white font-semibold py-3 px-4 rounded-lg transition-all"
            >
              {withdrawalMutation.isPending ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  <span>Processing...</span>
                </div>
              ) : (
                "Submit Withdrawal"
              )}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
