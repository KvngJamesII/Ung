import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import admin from "firebase-admin";
import { generateReferralCode } from "@shared/schema";
import { z } from "zod";
import { zodToJsonSchema } from "zod-to-json-schema";
import formidable from "formidable";
import fs from "fs/promises";
import path from "path";
import { insertUserSchema, insertTaskSchema, insertDepositSchema, insertWithdrawalSchema } from "@shared/schema";

// Set up multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    // Accept images only
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/i)) {
      // Instead of throwing an error, we'll just reject the file
      // and handle it gracefully in the route
      return cb(null, false);
    }
    cb(null, true);
  }
});

// Define upload directories
const UPLOAD_DIR = path.resolve(process.cwd(), "uploads");

// Ensure upload directories exist
async function ensureUploadDirs() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    await fs.mkdir(path.join(UPLOAD_DIR, "receipts"), { recursive: true });
    await fs.mkdir(path.join(UPLOAD_DIR, "proofs"), { recursive: true });
  } catch (err) {
    console.error("Error creating upload directories:", err);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize upload directories
  await ensureUploadDirs();
  
  // Middleware to verify Firebase token
  const verifyToken = async (req: any, res: any, next: any) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        console.log("Missing or invalid Authorization header", {
          headers: req.headers,
          method: req.method,
          path: req.path
        });
        return res.status(401).json({ message: 'Unauthorized - Missing or invalid token' });
      }
      
      const token = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await admin.auth().verifyIdToken(token);
        
        // Check if this user has a temporary account by email
        if (decodedToken.email) {
          const tempUser = await storage.getUserByEmail(decodedToken.email);
          
          if (tempUser && tempUser.uid.startsWith('temp_')) {
            console.log("Found temp user with matching email, updating UID", {
              email: decodedToken.email,
              oldUid: tempUser.uid,
              newUid: decodedToken.uid
            });
            
            // Update the user's UID to match their Firebase UID
            tempUser.uid = decodedToken.uid;
            
            // Save the updated user
            const user = await storage.getUser(tempUser.id);
            if (user) {
              user.uid = decodedToken.uid;
              // No need for a separate updateUser method as we're modifying the reference
            }
          }
        }
        
        req.user = decodedToken;
        console.log("Token verified successfully", { 
          uid: decodedToken.uid,
          email: decodedToken.email,
          path: req.path
        });
        next();
      } catch (tokenError: any) {
        console.error("Token validation failed:", tokenError);
        return res.status(401).json({ message: 'Unauthorized - Invalid token', error: tokenError.message || 'Token verification failed' });
      }
    } catch (error: any) {
      console.error("Error in auth middleware:", error);
      res.status(401).json({ message: 'Unauthorized - Server error', error: error.message || 'Unknown error' });
    }
  };

  // Middleware to verify admin role
  const verifyAdmin = (req: any, res: any, next: any) => {
    if (req.user && req.user.email === 'adedayomichael333@gmail.com') {
      next();
    } else {
      res.status(403).json({ message: 'Forbidden' });
    }
  };

  // USER ROUTES
  
  // Create a new user
  app.post('/api/users', async (req, res) => {
    try {
      console.log("Creating user with data:", req.body);
      
      // Modified schema validation to handle Firebase auth users
      const validatedData = {
        email: req.body.email,
        username: req.body.username || req.body.email.split('@')[0],
        // Default password for users coming from Firebase Auth
        password: req.body.password || `firebase_auth_${Date.now()}`,
      };
      
      // Check if user with email already exists
      let existingUser = await storage.getUserByEmail(validatedData.email);
      
      // Also check by UID in case email was changed in Firebase
      if (!existingUser && req.body.uid) {
        existingUser = await storage.getUserByUid(req.body.uid);
      }
      
      // If user exists, update their information and return
      if (existingUser) {
        console.log(`User already exists with ID ${existingUser.id}, email ${existingUser.email}`);
        return res.status(200).json(existingUser);
      }
      
      // Generate a unique referral code
      const referralCode = req.body.referralCode || generateReferralCode();
      
      // Create the user
      const newUser = await storage.createUser({
        ...validatedData,
        referralCode,
        uid: req.body.uid,
      });
      
      console.log(`Created new user with ID ${newUser.id}, email ${newUser.email}, uid ${newUser.uid}`);
      
      // Process referral if provided
      if (req.body.referredBy) {
        const referrer = await storage.getUserByReferralCode(req.body.referredBy);
        if (referrer) {
          await storage.createReferral(referrer.id, newUser.id);
          console.log(`Created referral relationship between ${referrer.id} and ${newUser.id}`);
        }
      }
      
      res.status(201).json(newUser);
    } catch (error: any) {
      console.error("Error creating user:", error);
      res.status(400).json({ message: error.message || 'Failed to create user' });
    }
  });

  // Get current user info
  app.get('/api/users/me', verifyToken, async (req: any, res) => {
    try {
      console.log("GET /api/users/me for UID:", req.user.uid);
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Don't send the password back to client
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      console.error("Error getting user:", error);
      res.status(500).json({ message: error.message || 'Failed to get user info' });
    }
  });
  
  // Logout endpoint
  app.post('/api/auth/logout', async (req, res) => {
    try {
      // Nothing to do on server side since we're using stateless JWT tokens
      // But this endpoint could be used for analytics or cleanup in the future
      console.log("User requested logout");
      res.status(200).json({ message: 'Logged out successfully' });
    } catch (error: any) {
      console.error("Error during logout:", error);
      res.status(500).json({ message: error.message || 'Failed to logout' });
    }
  });

  // TASK ROUTES
  
  // Create a new task
  app.post('/api/tasks', verifyToken, async (req: any, res) => {
    try {
      const validatedData = insertTaskSchema.parse(req.body);
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user is banned
      if (user.isBanned) {
        return res.status(403).json({ message: 'Your account has been banned' });
      }
      
      // Calculate total cost
      const totalCost = validatedData.price * validatedData.totalSlots;
      
      // Check if user has enough balance
      if (user.depositBalance < totalCost) {
        return res.status(400).json({ message: 'Insufficient funds in deposit balance' });
      }
      
      // Create the task
      const task = await storage.createTask({
        ...validatedData,
        ownerId: user.id,
        remainingSlots: validatedData.totalSlots,
      });
      
      // Deduct the cost from user's deposit balance
      await storage.updateUserBalance(user.id, user.depositBalance - totalCost, user.withdrawableBalance);
      
      // Record the transaction
      await storage.createTransaction({
        userId: user.id,
        type: 'task_debit',
        amount: totalCost,
        status: 'completed',
        description: `Created task: ${validatedData.name}`,
      });
      
      res.status(201).json(task);
    } catch (error: any) {
      console.error("Error creating task:", error);
      res.status(400).json({ message: error.message || 'Failed to create task' });
    }
  });

  // Get all available tasks
  app.get('/api/tasks', verifyToken, async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error: any) {
      console.error("Error getting tasks:", error);
      res.status(500).json({ message: error.message || 'Failed to get tasks' });
    }
  });
  
  // Get tasks created by the current user
  app.get('/api/my-tasks', verifyToken, async (req: any, res) => {
    try {
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const tasks = await storage.getTasksByOwner(user.id);
      res.json(tasks);
    } catch (error: any) {
      console.error("Error getting user's tasks:", error);
      res.status(500).json({ message: error.message || "Failed to get user's tasks" });
    }
  });
  
  // Get task completions for a specific task
  app.get('/api/my-tasks/:id/completions', verifyToken, async (req: any, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get the task
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      // Check if user is the owner of the task
      if (task.ownerId !== user.id) {
        return res.status(403).json({ message: 'You are not authorized to view this task' });
      }
      
      // Get all completions for this task
      const completions = await storage.getTaskCompletions(taskId);
      
      // Enrich with user information
      const completionsWithUsers = await Promise.all(
        completions.map(async (completion) => {
          const user = await storage.getUser(completion.userId);
          return {
            ...completion,
            user: user ? {
              id: user.id,
              username: user.username,
              email: user.email
            } : null
          };
        })
      );
      
      res.json(completionsWithUsers);
    } catch (error: any) {
      console.error("Error getting task completions:", error);
      res.status(500).json({ message: error.message || 'Failed to get task completions' });
    }
  });

  // Get a specific task
  app.get('/api/tasks/:id', verifyToken, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      res.json(task);
    } catch (error: any) {
      console.error("Error getting task:", error);
      res.status(500).json({ message: error.message || 'Failed to get task' });
    }
  });

  // Get IDs of tasks the user has completed
  app.get('/api/tasks/completed', verifyToken, async (req: any, res) => {
    try {
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const completedTasks = await storage.getUserCompletedTasks(user.id);
      const taskIds = completedTasks.map(completion => completion.taskId);
      
      res.json(taskIds);
    } catch (error: any) {
      console.error("Error getting completed tasks:", error);
      res.status(500).json({ message: error.message || 'Failed to get completed tasks' });
    }
  });

  // Complete a task (submit proof)
  app.post('/api/tasks/:id/complete', verifyToken, upload.single('imageProof'), async (req: any, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const { textProof } = req.body;
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user is banned
      if (user.isBanned) {
        return res.status(403).json({ message: 'Your account has been banned' });
      }
      
      // Get the task
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      // Check if task has available slots
      if (task.remainingSlots <= 0) {
        return res.status(400).json({ message: 'No slots left for this task' });
      }
      
      // Check if user is the owner of the task
      if (task.ownerId === user.id) {
        return res.status(400).json({ message: 'You cannot complete your own task' });
      }
      
      // Check if user has already completed this task
      const existingCompletion = await storage.getTaskCompletion(taskId, user.id);
      if (existingCompletion) {
        return res.status(400).json({ message: 'You have already completed this task' });
      }
      
      // Process image proof if provided
      let imageProofPath = null;
      if (req.file) {
        const fileExt = path.extname(req.file.originalname);
        const fileName = `proof_${taskId}_${user.id}_${Date.now()}${fileExt}`;
        const filePath = path.join(UPLOAD_DIR, "proofs", fileName);
        
        await fs.writeFile(filePath, req.file.buffer);
        imageProofPath = fileName;
      }
      
      // Require at least one form of proof
      if (!textProof && !imageProofPath) {
        return res.status(400).json({ message: 'Please provide either text proof or image proof' });
      }
      
      // Create task completion record
      const completion = await storage.createTaskCompletion({
        taskId,
        userId: user.id,
        textProof: textProof || null,
        imageProof: imageProofPath,
      });
      
      // Create notification for task owner
      await storage.createNotification({
        userId: task.ownerId,
        message: 'A user has completed your task. Please review.',
        type: 'task_completion',
        relatedId: completion.id,
        isRead: false,
      });
      
      res.status(201).json(completion);
    } catch (error: any) {
      console.error("Error completing task:", error);
      res.status(400).json({ message: error.message || 'Failed to complete task' });
    }
  });

  // Get task completion for current user
  app.get('/api/tasks/:id/completion', verifyToken, async (req: any, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get the task completion
      const completion = await storage.getTaskCompletion(taskId, user.id);
      if (!completion) {
        return res.status(404).json({ message: 'Task completion not found' });
      }
      
      res.json(completion);
    } catch (error: any) {
      console.error("Error getting task completion:", error);
      res.status(500).json({ message: error.message || 'Failed to get task completion' });
    }
  });

  // Review task completion (approve/reject)
  app.post('/api/tasks/completions/:id/review', verifyToken, async (req: any, res) => {
    try {
      const completionId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (status !== 'approved' && status !== 'rejected') {
        return res.status(400).json({ message: 'Status must be either "approved" or "rejected"' });
      }
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get the task completion
      const completion = await storage.getTaskCompletionById(completionId);
      if (!completion) {
        return res.status(404).json({ message: 'Task completion not found' });
      }
      
      // Get the task
      const task = await storage.getTask(completion.taskId);
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }
      
      // Check if user is the owner of the task
      if (task.ownerId !== user.id) {
        return res.status(403).json({ message: 'You are not authorized to review this task' });
      }
      
      // Update the completion status
      await storage.updateTaskCompletionStatus(completionId, status);
      
      // Get the user who completed the task
      const taskCompleter = await storage.getUser(completion.userId);
      if (!taskCompleter) {
        return res.status(404).json({ message: 'Task completer not found' });
      }
      
      if (status === 'approved') {
        // Update task's remaining slots
        const newRemainingSlots = task.remainingSlots - 1;
        await storage.updateTaskSlots(task.id, newRemainingSlots);
        
        // Mark task as completed if no slots left
        if (newRemainingSlots <= 0) {
          await storage.updateTaskCompletion(task.id, true);
        }
        
        // Credit the task completer
        const newWithdrawableBalance = taskCompleter.withdrawableBalance + task.price;
        await storage.updateUserBalance(
          taskCompleter.id,
          taskCompleter.depositBalance,
          newWithdrawableBalance
        );
        
        // Record the transaction
        await storage.createTransaction({
          userId: taskCompleter.id,
          type: 'task_credit',
          amount: task.price,
          status: 'completed',
          description: `Completed task: ${task.name}`,
        });
        
        // Create notification for task completer
        await storage.createNotification({
          userId: taskCompleter.id,
          message: 'Your task submission has been approved!',
          type: 'task_approved',
          relatedId: task.id,
          isRead: false,
        });
      } else {
        // Create notification for task completer
        await storage.createNotification({
          userId: taskCompleter.id,
          message: 'Your task submission was rejected.',
          type: 'task_rejected',
          relatedId: task.id,
          isRead: false,
        });
      }
      
      res.json({ message: `Task completion ${status}` });
    } catch (error: any) {
      console.error("Error reviewing task:", error);
      res.status(500).json({ message: error.message || 'Failed to review task' });
    }
  });

  // WALLET ROUTES
  
  // Submit a deposit request (no auth required)
  app.post('/api/deposits', upload.single('paymentReceipt'), async (req: any, res) => {
    try {
      console.log('Deposit request received', {
        body: req.body,
        file: req.file ? {
          originalname: req.file.originalname,
          mimetype: req.file.mimetype,
          size: req.file.size
        } : 'No file uploaded'
      });
      
      const { amount, paymentName, email } = req.body;
      
      if (!amount || isNaN(parseFloat(amount))) {
        console.log('Invalid amount:', amount);
        return res.status(400).json({ message: 'Valid amount is required' });
      }
      
      if (!email) {
        console.log('No email provided');
        return res.status(400).json({ message: 'Email is required' });
      }
      
      // Get the user by email
      let user = await storage.getUserByEmail(email);
      if (!user) {
        console.log('User not found with email:', email);
        // Create a temporary user to track the deposit for admin
        user = await storage.createUser({
          uid: 'temp_' + Date.now(),
          email: email,
          username: 'temp_user_' + Date.now(),
          password: 'temp',
          referralCode: generateReferralCode()
        });
        
        // Process with temporary user
        console.log('Created temporary user for deposit tracking:', user.id);
      } else {
        console.log('User found:', {
          id: user.id,
          email: user.email,
          isBanned: user.isBanned
        });
        
        // Check if user is banned
        if (user.isBanned) {
          return res.status(403).json({ message: 'Your account has been banned' });
        }
      }
      
      // At this point, user is guaranteed to be defined
      
      // Process receipt if provided
      let receiptPath = null;
      if (req.file) {
        try {
          const fileExt = path.extname(req.file.originalname);
          const fileName = `receipt_${user.id}_${Date.now()}${fileExt}`;
          const filePath = path.join(UPLOAD_DIR, "receipts", fileName);
          
          // Ensure directory exists again just to be safe
          await fs.mkdir(path.join(UPLOAD_DIR, "receipts"), { recursive: true });
          
          // Write the file
          await fs.writeFile(filePath, req.file.buffer);
          receiptPath = fileName;
          console.log('Receipt file saved successfully:', fileName);
        } catch (fileError: any) {
          console.error('Error saving receipt file:', fileError);
          // Continue even if file saving fails
        }
      }
      
      // Create transaction record
      const transaction = await storage.createTransaction({
        userId: user.id,
        type: 'deposit',
        amount: parseFloat(amount),
        status: 'pending',
        description: 'Deposit request',
      });
      
      console.log('Transaction created:', {
        id: transaction.id,
        amount: transaction.amount
      });
      
      // Create deposit record
      const deposit = await storage.createDeposit({
        transactionId: transaction.id,
        userId: user.id,
        amount: parseFloat(amount),
        paymentName: paymentName || null,
        paymentReceipt: receiptPath,
        status: 'pending',
      });
      
      console.log('Deposit created:', {
        id: deposit.id,
        amount: deposit.amount,
        receipt: deposit.paymentReceipt
      });
      
      // Create notification for admin
      await storage.createNotification({
        userId: 1, // Admin user ID
        message: `New deposit request: ₦${amount} from ${user.email}`,
        type: 'deposit',
        relatedId: deposit.id,
        isRead: false,
      });
      
      // Create notification for user
      await storage.createNotification({
        userId: user.id,
        message: 'Your deposit request is being processed',
        type: 'deposit',
        relatedId: deposit.id,
        isRead: false,
      });
      
      res.status(201).json(deposit);
    } catch (error: any) {
      console.error("Error creating deposit:", error);
      res.status(400).json({ message: error.message || 'Failed to create deposit request' });
    }
  });

  // Submit a withdrawal request
  app.post('/api/withdrawals', verifyToken, async (req: any, res) => {
    try {
      const validatedData = insertWithdrawalSchema.parse(req.body);
      
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user is banned
      if (user.isBanned) {
        return res.status(403).json({ message: 'Your account has been banned' });
      }
      
      // Check if user has enough balance
      if (user.withdrawableBalance < validatedData.amount) {
        return res.status(400).json({ message: 'Insufficient funds in withdrawable balance' });
      }
      
      // Create transaction record
      const transaction = await storage.createTransaction({
        userId: user.id,
        type: 'withdrawal',
        amount: validatedData.amount,
        status: 'pending',
        description: 'Withdrawal request',
      });
      
      // Create withdrawal record
      const withdrawal = await storage.createWithdrawal({
        transactionId: transaction.id,
        userId: user.id,
        amount: validatedData.amount,
        network: validatedData.network,
        phoneNumber: validatedData.phoneNumber,
        status: 'pending',
      });
      
      // Deduct the amount from user's withdrawable balance
      await storage.updateUserBalance(
        user.id,
        user.depositBalance,
        user.withdrawableBalance - validatedData.amount
      );
      
      // Create notification for admin
      await storage.createNotification({
        userId: 1, // Admin user ID
        message: `New withdrawal request: ₦${validatedData.amount} from ${user.email}`,
        type: 'withdrawal',
        relatedId: withdrawal.id,
        isRead: false,
      });
      
      // Create notification for user
      await storage.createNotification({
        userId: user.id,
        message: 'Your withdrawal request is being processed',
        type: 'withdrawal',
        relatedId: withdrawal.id,
        isRead: false,
      });
      
      res.status(201).json(withdrawal);
    } catch (error: any) {
      console.error("Error creating withdrawal:", error);
      res.status(400).json({ message: error.message || 'Failed to create withdrawal request' });
    }
  });

  // Get transaction history for current user
  app.get('/api/transactions', verifyToken, async (req: any, res) => {
    try {
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get user's transactions
      const transactions = await storage.getUserTransactions(user.id);
      
      res.json(transactions);
    } catch (error: any) {
      console.error("Error getting transactions:", error);
      res.status(500).json({ message: error.message || 'Failed to get transactions' });
    }
  });

  // NOTIFICATION ROUTES
  
  // Get notifications for current user
  app.get('/api/notifications', verifyToken, async (req: any, res) => {
    try {
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get user's notifications
      const notifications = await storage.getUserNotifications(user.id);
      
      res.json(notifications);
    } catch (error: any) {
      console.error("Error getting notifications:", error);
      res.status(500).json({ message: error.message || 'Failed to get notifications' });
    }
  });

  // Mark all notifications as read
  app.post('/api/notifications/read-all', verifyToken, async (req: any, res) => {
    try {
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Mark all notifications as read
      await storage.markAllNotificationsAsRead(user.id);
      
      res.json({ message: 'All notifications marked as read' });
    } catch (error: any) {
      console.error("Error marking notifications as read:", error);
      res.status(500).json({ message: error.message || 'Failed to mark notifications as read' });
    }
  });

  // REFERRAL ROUTES
  
  // Get referrals for current user
  app.get('/api/referrals', verifyToken, async (req: any, res) => {
    try {
      // Get the current user
      const user = await storage.getUserByUid(req.user.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get user's referrals
      const referrals = await storage.getUserReferrals(user.id);
      
      res.json(referrals);
    } catch (error: any) {
      console.error("Error getting referrals:", error);
      res.status(500).json({ message: error.message || 'Failed to get referrals' });
    }
  });

  // ADMIN ROUTES
  
  // Get all pending deposits
  app.get('/api/admin/deposits', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const deposits = await storage.getPendingDeposits();
      res.json(deposits);
    } catch (error: any) {
      console.error("Error getting deposits:", error);
      res.status(500).json({ message: error.message || 'Failed to get deposits' });
    }
  });

  // Approve a deposit
  app.post('/api/admin/deposits/:id/approve', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const depositId = parseInt(req.params.id);
      
      // Get the deposit
      const deposit = await storage.getDeposit(depositId);
      if (!deposit) {
        return res.status(404).json({ message: 'Deposit not found' });
      }
      
      // Get the user
      const user = await storage.getUser(deposit.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      console.log('Processing deposit approval for user:', {
        id: user.id,
        email: user.email,
        uid: user.uid,
        currentDepositBalance: user.depositBalance,
        currentWithdrawableBalance: user.withdrawableBalance
      });
      
      // Update deposit status
      await storage.updateDepositStatus(depositId, 'approved');
      
      // Update transaction status
      await storage.updateTransactionStatus(deposit.transactionId, 'completed');
      
      // Calculate service fee (₦100)
      const amountAfterFee = deposit.amount - 100;
      
      // Update user's deposit balance
      const newDepositBalance = user.depositBalance + amountAfterFee;
      
      console.log('Updating user balance:', {
        userId: user.id,
        oldDepositBalance: user.depositBalance,
        newDepositBalance: newDepositBalance,
        withdrawableBalance: user.withdrawableBalance,
        amountAdded: amountAfterFee
      });
      
      await storage.updateUserBalance(user.id, newDepositBalance, user.withdrawableBalance);
      
      // Create notification for user
      await storage.createNotification({
        userId: user.id,
        message: `Your deposit of ₦${deposit.amount} has been approved. ₦${amountAfterFee} added to your balance after service fee.`,
        type: 'deposit',
        relatedId: deposit.id,
        isRead: false,
      });
      
      // Process referral bonus if applicable
      const referral = await storage.getUserReferrer(user.id);
      if (referral) {
        const referrer = await storage.getUser(referral.referrerId);
        if (referrer) {
          // Fixed bonus amount of ₦25
          const bonusAmount = 25;
          
          // Update referrer's withdrawable balance
          const newWithdrawableBalance = referrer.withdrawableBalance + bonusAmount;
          await storage.updateUserBalance(referrer.id, referrer.depositBalance, newWithdrawableBalance);
          
          // Update referral with bonus amount
          await storage.updateReferralBonus(referral.id, bonusAmount);
          
          // Record the transaction
          await storage.createTransaction({
            userId: referrer.id,
            type: 'referral_bonus',
            amount: bonusAmount,
            status: 'completed',
            description: `Referral bonus from ${user.username}'s deposit`,
          });
          
          // Create notification for referrer
          await storage.createNotification({
            userId: referrer.id,
            message: `You earned ₦25 referral bonus from ${user.username}'s deposit!`,
            type: 'referral',
            relatedId: referral.id,
            isRead: false,
          });
        }
      }
      
      res.json({ message: 'Deposit approved successfully' });
    } catch (error: any) {
      console.error("Error approving deposit:", error);
      res.status(500).json({ message: error.message || 'Failed to approve deposit' });
    }
  });

  // Reject a deposit
  app.post('/api/admin/deposits/:id/reject', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const depositId = parseInt(req.params.id);
      
      // Get the deposit
      const deposit = await storage.getDeposit(depositId);
      if (!deposit) {
        return res.status(404).json({ message: 'Deposit not found' });
      }
      
      // Update deposit status
      await storage.updateDepositStatus(depositId, 'rejected');
      
      // Update transaction status
      await storage.updateTransactionStatus(deposit.transactionId, 'rejected');
      
      // Create notification for user
      await storage.createNotification({
        userId: deposit.userId,
        message: `Your deposit of ₦${deposit.amount} has been rejected.`,
        type: 'deposit',
        relatedId: deposit.id,
        isRead: false,
      });
      
      res.json({ message: 'Deposit rejected successfully' });
    } catch (error: any) {
      console.error("Error rejecting deposit:", error);
      res.status(500).json({ message: error.message || 'Failed to reject deposit' });
    }
  });

  // Get all pending withdrawals
  app.get('/api/admin/withdrawals', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const withdrawals = await storage.getPendingWithdrawals();
      res.json(withdrawals);
    } catch (error: any) {
      console.error("Error getting withdrawals:", error);
      res.status(500).json({ message: error.message || 'Failed to get withdrawals' });
    }
  });

  // Complete a withdrawal
  app.post('/api/admin/withdrawals/:id/complete', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      
      // Get the withdrawal
      const withdrawal = await storage.getWithdrawal(withdrawalId);
      if (!withdrawal) {
        return res.status(404).json({ message: 'Withdrawal not found' });
      }
      
      // Update withdrawal status
      await storage.updateWithdrawalStatus(withdrawalId, 'completed');
      
      // Update transaction status
      await storage.updateTransactionStatus(withdrawal.transactionId, 'completed');
      
      // Create notification for user
      await storage.createNotification({
        userId: withdrawal.userId,
        message: `Your withdrawal of ₦${withdrawal.amount} has been completed.`,
        type: 'withdrawal',
        relatedId: withdrawal.id,
        isRead: false,
      });
      
      res.json({ message: 'Withdrawal completed successfully' });
    } catch (error: any) {
      console.error("Error completing withdrawal:", error);
      res.status(500).json({ message: error.message || 'Failed to complete withdrawal' });
    }
  });

  // Get admin dashboard stats
  app.get('/api/admin/stats', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const userCount = await storage.getUserCount();
      const activeTaskCount = await storage.getActiveTaskCount();
      
      res.json({
        userCount,
        activeTaskCount,
      });
    } catch (error: any) {
      console.error("Error getting admin stats:", error);
      res.status(500).json({ message: error.message || 'Failed to get admin stats' });
    }
  });

  // Get user by ID
  app.get('/api/admin/users/:id', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      
      // Try to get user by ID first
      let user;
      if (!isNaN(parseInt(userId))) {
        user = await storage.getUser(parseInt(userId));
      }
      
      // If not found, try to get by referral code
      if (!user) {
        user = await storage.getUserByReferralCode(userId);
      }
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Don't send the password back to client
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      console.error("Error getting user:", error);
      res.status(500).json({ message: error.message || 'Failed to get user' });
    }
  });

  // Ban a user
  app.post('/api/admin/users/:id/ban', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Get the user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Update user's ban status
      await storage.updateUserBanStatus(userId, true);
      
      res.json({ message: 'User banned successfully' });
    } catch (error: any) {
      console.error("Error banning user:", error);
      res.status(500).json({ message: error.message || 'Failed to ban user' });
    }
  });

  // Unban a user
  app.post('/api/admin/users/:id/unban', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Get the user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Update user's ban status
      await storage.updateUserBanStatus(userId, false);
      
      res.json({ message: 'User unbanned successfully' });
    } catch (error: any) {
      console.error("Error unbanning user:", error);
      res.status(500).json({ message: error.message || 'Failed to unban user' });
    }
  });

  // Add balance to a user
  app.post('/api/admin/users/:id/add-balance', verifyToken, verifyAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { amount, type } = req.body;
      
      if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
        return res.status(400).json({ message: 'Valid amount is required' });
      }
      
      if (type !== 'deposit' && type !== 'withdrawal') {
        return res.status(400).json({ message: 'Type must be either "deposit" or "withdrawal"' });
      }
      
      // Get the user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Update user's balance based on type
      if (type === 'deposit') {
        await storage.updateUserBalance(
          userId,
          user.depositBalance + parseFloat(amount),
          user.withdrawableBalance
        );
      } else {
        await storage.updateUserBalance(
          userId,
          user.depositBalance,
          user.withdrawableBalance + parseFloat(amount)
        );
      }
      
      // Record the transaction
      await storage.createTransaction({
        userId,
        type: type === 'deposit' ? 'deposit' : 'withdrawal',
        amount: parseFloat(amount),
        status: 'completed',
        description: `Admin added ${type} balance`,
      });
      
      // Create notification for user
      await storage.createNotification({
        userId,
        message: `Admin added ₦${amount} to your ${type === 'deposit' ? 'deposit' : 'withdrawable'} balance.`,
        type: type === 'deposit' ? 'deposit' : 'withdrawal',
        relatedId: null,
        isRead: false,
      });
      
      res.json({ message: 'Balance added successfully' });
    } catch (error: any) {
      console.error("Error adding balance:", error);
      res.status(500).json({ message: error.message || 'Failed to add balance' });
    }
  });

  // Get receipt image
  app.get('/api/deposits/:id/receipt', async (req, res) => {
    try {
      const depositId = parseInt(req.params.id);
      
      // Get the deposit
      const deposit = await storage.getDeposit(depositId);
      if (!deposit || !deposit.paymentReceipt) {
        return res.status(404).json({ message: 'Receipt not found' });
      }
      
      const receiptPath = path.join(UPLOAD_DIR, "receipts", deposit.paymentReceipt);
      
      // Check if file exists
      try {
        await fs.access(receiptPath);
      } catch (err) {
        return res.status(404).json({ message: 'Receipt file not found' });
      }
      
      res.sendFile(receiptPath);
    } catch (error: any) {
      console.error("Error getting receipt:", error);
      res.status(500).json({ message: error.message || 'Failed to get receipt' });
    }
  });

  // Get proof image
  app.get('/api/tasks/completions/:id/proof', async (req, res) => {
    try {
      const completionId = parseInt(req.params.id);
      
      // Get the completion
      const completion = await storage.getTaskCompletionById(completionId);
      if (!completion || !completion.imageProof) {
        return res.status(404).json({ message: 'Proof not found' });
      }
      
      const proofPath = path.join(UPLOAD_DIR, "proofs", completion.imageProof);
      
      // Check if file exists
      try {
        await fs.access(proofPath);
      } catch (err) {
        return res.status(404).json({ message: 'Proof file not found' });
      }
      
      res.sendFile(proofPath);
    } catch (error: any) {
      console.error("Error getting proof:", error);
      res.status(500).json({ message: error.message || 'Failed to get proof' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
