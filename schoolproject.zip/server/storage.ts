import { 
  users, tasks, taskCompletions, transactions, deposits, 
  withdrawals, notifications, referrals,
  type User, type InsertUser, type Task, type InsertTask,
  type TaskCompletion, type InsertTaskCompletion, type Transaction,
  type Deposit, type InsertDeposit, type Withdrawal, type InsertWithdrawal,
  type Notification, type Referral
} from "@shared/schema";

export interface IStorage {
  // User methods
  createUser(user: InsertUser & { uid: string, referralCode: string, password: string }): Promise<User>;
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByUid(uid: string): Promise<User | undefined>;
  getUserByReferralCode(referralCode: string): Promise<User | undefined>;
  updateUserBalance(userId: number, depositBalance: number, withdrawableBalance: number): Promise<void>;
  updateUserBanStatus(userId: number, isBanned: boolean): Promise<void>;
  updateUser(userId: number, userData: Partial<User>): Promise<void>;
  getUserCount(): Promise<number>;

  // Task methods
  createTask(task: InsertTask & { ownerId: number, remainingSlots: number }): Promise<Task>;
  getTask(id: number): Promise<Task | undefined>;
  getTasks(): Promise<Task[]>;
  getTasksByOwner(ownerId: number): Promise<Task[]>;
  updateTaskSlots(taskId: number, remainingSlots: number): Promise<void>;
  updateTaskCompletion(taskId: number, isCompleted: boolean): Promise<void>;
  getActiveTaskCount(): Promise<number>;

  // Task completion methods
  createTaskCompletion(completion: InsertTaskCompletion & { userId: number }): Promise<TaskCompletion>;
  getTaskCompletion(taskId: number, userId: number): Promise<TaskCompletion | undefined>;
  getTaskCompletionById(id: number): Promise<TaskCompletion | undefined>;
  getTaskCompletions(taskId: number): Promise<TaskCompletion[]>;
  updateTaskCompletionStatus(id: number, status: string): Promise<void>;
  getUserCompletedTasks(userId: number): Promise<TaskCompletion[]>;

  // Transaction methods
  createTransaction(transaction: Omit<Transaction, 'id' | 'createdAt' | 'completedAt'>): Promise<Transaction>;
  updateTransactionStatus(id: number, status: string): Promise<void>;
  getUserTransactions(userId: number): Promise<Transaction[]>;

  // Deposit methods
  createDeposit(deposit: Omit<Deposit, 'id' | 'createdAt' | 'completedAt'>): Promise<Deposit>;
  getDeposit(id: number): Promise<Deposit | undefined>;
  updateDepositStatus(id: number, status: string): Promise<void>;
  getPendingDeposits(): Promise<(Deposit & { user: User })[]>;

  // Withdrawal methods
  createWithdrawal(withdrawal: Omit<Withdrawal, 'id' | 'createdAt' | 'completedAt'>): Promise<Withdrawal>;
  getWithdrawal(id: number): Promise<Withdrawal | undefined>;
  updateWithdrawalStatus(id: number, status: string): Promise<void>;
  getPendingWithdrawals(): Promise<(Withdrawal & { user: User })[]>;

  // Notification methods
  createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  markAllNotificationsAsRead(userId: number): Promise<void>;

  // Referral methods
  createReferral(referrerId: number, referredId: number): Promise<Referral>;
  getUserReferrals(referrerId: number): Promise<Referral[]>;
  getUserReferrer(referredId: number): Promise<Referral | undefined>;
  updateReferralBonus(id: number, bonus: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private taskCompletions: Map<number, TaskCompletion>;
  private transactions: Map<number, Transaction>;
  private deposits: Map<number, Deposit>;
  private withdrawals: Map<number, Withdrawal>;
  private notifications: Map<number, Notification>;
  private referrals: Map<number, Referral>;
  
  private currentUserId: number;
  private currentTaskId: number;
  private currentTaskCompletionId: number;
  private currentTransactionId: number;
  private currentDepositId: number;
  private currentWithdrawalId: number;
  private currentNotificationId: number;
  private currentReferralId: number;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.taskCompletions = new Map();
    this.transactions = new Map();
    this.deposits = new Map();
    this.withdrawals = new Map();
    this.notifications = new Map();
    this.referrals = new Map();
    
    this.currentUserId = 1;
    this.currentTaskId = 1;
    this.currentTaskCompletionId = 1;
    this.currentTransactionId = 1;
    this.currentDepositId = 1;
    this.currentWithdrawalId = 1;
    this.currentNotificationId = 1;
    this.currentReferralId = 1;
    
    // Create admin user
    this.createUser({
      username: 'admin',
      email: 'adedayomichael333@gmail.com',
      password: 'isr828',
      uid: '6SOIHeamN7b49NcI61g20naScB13', // Updated to match Firebase UID
      referralCode: 'ADMIN'
    });
  }

  // USER METHODS
  async createUser(data: InsertUser & { uid: string, referralCode: string }): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    
    const user: User = {
      id,
      uid: data.uid,
      username: data.username,
      email: data.email,
      password: data.password,
      referralCode: data.referralCode,
      referredBy: data.referralCode || null,
      depositBalance: 0,
      withdrawableBalance: 0,
      createdAt: now,
      isBanned: false
    };
    
    this.users.set(id, user);
    return user;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByUid(uid: string): Promise<User | undefined> {
    // First try to find by exact UID match
    let user = Array.from(this.users.values()).find(user => user.uid === uid);
    
    if (user) {
      console.log(`Found user by UID ${uid}: ID ${user.id}, email ${user.email}`);
      return user;
    }
    
    // If the UID starts with 'firebase:', try to get the email from the UID
    if (uid && uid.includes('@')) {
      const email = uid;
      
      // Try to find a user with a matching email who might have a temporary UID
      const tempUser = Array.from(this.users.values()).find(u => 
        u.email === email && u.uid.startsWith('temp_')
      );
      
      if (tempUser) {
        console.log(`Found temporary user with matching email ${email}. Updating UID.`);
        console.log(`Updating user ${tempUser.id} UID from ${tempUser.uid} to ${uid}`);
        
        // Update the temporary user's UID to match their Firebase UID
        tempUser.uid = uid;
        this.users.set(tempUser.id, tempUser);
        
        return tempUser;
      }
    }
    
    console.log(`No user found for UID ${uid}`);
    return undefined;
  }

  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.referralCode === referralCode);
  }

  async updateUserBalance(userId: number, depositBalance: number, withdrawableBalance: number): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      console.log('Updating balance for user:', {
        id: user.id,
        email: user.email,
        oldDepositBalance: user.depositBalance,
        newDepositBalance: depositBalance,
        oldWithdrawableBalance: user.withdrawableBalance,
        newWithdrawableBalance: withdrawableBalance
      });
      
      user.depositBalance = depositBalance;
      user.withdrawableBalance = withdrawableBalance;
      this.users.set(userId, user);
      
      // Re-fetch user to verify update
      const updatedUser = await this.getUser(userId);
      if (updatedUser) {
        console.log('User balance after update:', {
          id: updatedUser.id,
          email: updatedUser.email,
          depositBalance: updatedUser.depositBalance,
          withdrawableBalance: updatedUser.withdrawableBalance
        });
      }
    } else {
      console.error('Failed to update balance: User not found with ID', userId);
    }
  }

  async updateUserBanStatus(userId: number, isBanned: boolean): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      user.isBanned = isBanned;
      this.users.set(userId, user);
    }
  }

  async updateUser(userId: number, userData: Partial<User>): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      console.log(`Updating user ${userId} with data:`, userData);
      
      // Update user properties
      Object.assign(user, userData);
      
      // Save the updated user
      this.users.set(userId, user);
      console.log(`User ${userId} updated successfully`);
    } else {
      console.error(`Cannot update user ${userId}: User not found`);
    }
  }

  async getUserCount(): Promise<number> {
    return this.users.size;
  }

  // TASK METHODS
  async createTask(data: InsertTask & { ownerId: number, remainingSlots: number }): Promise<Task> {
    const id = this.currentTaskId++;
    const now = new Date();
    
    const task: Task = {
      id,
      name: data.name,
      description: data.description,
      link: data.link,
      price: data.price,
      totalSlots: data.totalSlots,
      remainingSlots: data.remainingSlots,
      ownerId: data.ownerId,
      createdAt: now,
      isCompleted: false
    };
    
    this.tasks.set(id, task);
    return task;
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }
  
  async getTasksByOwner(ownerId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.ownerId === ownerId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateTaskSlots(taskId: number, remainingSlots: number): Promise<void> {
    const task = await this.getTask(taskId);
    if (task) {
      task.remainingSlots = remainingSlots;
      this.tasks.set(taskId, task);
    }
  }

  async updateTaskCompletion(taskId: number, isCompleted: boolean): Promise<void> {
    const task = await this.getTask(taskId);
    if (task) {
      task.isCompleted = isCompleted;
      this.tasks.set(taskId, task);
    }
  }

  async getActiveTaskCount(): Promise<number> {
    return Array.from(this.tasks.values()).filter(task => !task.isCompleted).length;
  }

  // TASK COMPLETION METHODS
  async createTaskCompletion(data: InsertTaskCompletion & { userId: number }): Promise<TaskCompletion> {
    const id = this.currentTaskCompletionId++;
    const now = new Date();
    
    const completion: TaskCompletion = {
      id,
      taskId: data.taskId,
      userId: data.userId,
      textProof: data.textProof || null,
      imageProof: data.imageProof || null,
      status: 'pending',
      createdAt: now,
      reviewedAt: null
    };
    
    this.taskCompletions.set(id, completion);
    return completion;
  }

  async getTaskCompletion(taskId: number, userId: number): Promise<TaskCompletion | undefined> {
    return Array.from(this.taskCompletions.values()).find(
      completion => completion.taskId === taskId && completion.userId === userId
    );
  }

  async getTaskCompletionById(id: number): Promise<TaskCompletion | undefined> {
    return this.taskCompletions.get(id);
  }
  
  async getTaskCompletions(taskId: number): Promise<TaskCompletion[]> {
    return Array.from(this.taskCompletions.values())
      .filter(completion => completion.taskId === taskId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateTaskCompletionStatus(id: number, status: string): Promise<void> {
    const completion = await this.getTaskCompletionById(id);
    if (completion) {
      completion.status = status;
      completion.reviewedAt = new Date();
      this.taskCompletions.set(id, completion);
    }
  }

  async getUserCompletedTasks(userId: number): Promise<TaskCompletion[]> {
    return Array.from(this.taskCompletions.values()).filter(
      completion => completion.userId === userId
    );
  }

  // TRANSACTION METHODS
  async createTransaction(data: Omit<Transaction, 'id' | 'createdAt' | 'completedAt'>): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const now = new Date();
    
    const transaction: Transaction = {
      id,
      userId: data.userId,
      type: data.type,
      amount: data.amount,
      status: data.status,
      description: data.description || null,
      createdAt: now,
      completedAt: data.status === 'completed' ? now : null
    };
    
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionStatus(id: number, status: string): Promise<void> {
    const transaction = this.transactions.get(id);
    if (transaction) {
      transaction.status = status;
      transaction.completedAt = status === 'completed' ? new Date() : null;
      this.transactions.set(id, transaction);
    }
  }

  async getUserTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // DEPOSIT METHODS
  async createDeposit(data: Omit<Deposit, 'id' | 'createdAt' | 'completedAt'>): Promise<Deposit> {
    const id = this.currentDepositId++;
    const now = new Date();
    
    const deposit: Deposit = {
      id,
      transactionId: data.transactionId,
      userId: data.userId,
      amount: data.amount,
      paymentName: data.paymentName,
      paymentReceipt: data.paymentReceipt,
      status: data.status,
      createdAt: now,
      completedAt: null
    };
    
    this.deposits.set(id, deposit);
    return deposit;
  }

  async getDeposit(id: number): Promise<Deposit | undefined> {
    return this.deposits.get(id);
  }

  async updateDepositStatus(id: number, status: string): Promise<void> {
    const deposit = this.deposits.get(id);
    if (deposit) {
      deposit.status = status;
      deposit.completedAt = status === 'approved' || status === 'rejected' ? new Date() : null;
      this.deposits.set(id, deposit);
    }
  }

  async getPendingDeposits(): Promise<(Deposit & { user: User })[]> {
    return Array.from(this.deposits.values())
      .filter(deposit => deposit.status === 'pending')
      .map(deposit => {
        const user = this.users.get(deposit.userId);
        return {
          ...deposit,
          user: user!
        };
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // WITHDRAWAL METHODS
  async createWithdrawal(data: Omit<Withdrawal, 'id' | 'createdAt' | 'completedAt'>): Promise<Withdrawal> {
    const id = this.currentWithdrawalId++;
    const now = new Date();
    
    const withdrawal: Withdrawal = {
      id,
      transactionId: data.transactionId,
      userId: data.userId,
      amount: data.amount,
      network: data.network,
      phoneNumber: data.phoneNumber,
      status: data.status,
      createdAt: now,
      completedAt: null
    };
    
    this.withdrawals.set(id, withdrawal);
    return withdrawal;
  }

  async getWithdrawal(id: number): Promise<Withdrawal | undefined> {
    return this.withdrawals.get(id);
  }

  async updateWithdrawalStatus(id: number, status: string): Promise<void> {
    const withdrawal = this.withdrawals.get(id);
    if (withdrawal) {
      withdrawal.status = status;
      withdrawal.completedAt = status === 'completed' ? new Date() : null;
      this.withdrawals.set(id, withdrawal);
    }
  }

  async getPendingWithdrawals(): Promise<(Withdrawal & { user: User })[]> {
    return Array.from(this.withdrawals.values())
      .filter(withdrawal => withdrawal.status === 'pending')
      .map(withdrawal => {
        const user = this.users.get(withdrawal.userId);
        return {
          ...withdrawal,
          user: user!
        };
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // NOTIFICATION METHODS
  async createNotification(data: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const id = this.currentNotificationId++;
    const now = new Date();
    
    const notification: Notification = {
      id,
      userId: data.userId,
      message: data.message,
      isRead: data.isRead,
      type: data.type,
      relatedId: data.relatedId,
      createdAt: now
    };
    
    this.notifications.set(id, notification);
    return notification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId && !notification.isRead)
      .forEach(notification => {
        notification.isRead = true;
        this.notifications.set(notification.id, notification);
      });
  }

  // REFERRAL METHODS
  async createReferral(referrerId: number, referredId: number): Promise<Referral> {
    const id = this.currentReferralId++;
    const now = new Date();
    
    const referral: Referral = {
      id,
      referrerId,
      referredId,
      bonus: 0,
      createdAt: now
    };
    
    this.referrals.set(id, referral);
    
    // Create notification for referrer
    await this.createNotification({
      userId: referrerId,
      message: 'You have a new referral!',
      type: 'referral',
      relatedId: id,
      isRead: false
    });
    
    return referral;
  }

  async getUserReferrals(referrerId: number): Promise<Referral[]> {
    return Array.from(this.referrals.values())
      .filter(referral => referral.referrerId === referrerId);
  }

  async getUserReferrer(referredId: number): Promise<Referral | undefined> {
    return Array.from(this.referrals.values())
      .find(referral => referral.referredId === referredId);
  }

  async updateReferralBonus(id: number, bonus: number): Promise<void> {
    const referral = this.referrals.get(id);
    if (referral) {
      referral.bonus = bonus;
      this.referrals.set(id, referral);
    }
  }
}

export const storage = new MemStorage();
