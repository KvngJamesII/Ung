import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { nanoid } from "nanoid";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(), // Firebase UID
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  depositBalance: doublePrecision("deposit_balance").notNull().default(0),
  withdrawableBalance: doublePrecision("withdrawable_balance").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  isBanned: boolean("is_banned").notNull().default(false),
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  link: text("link").notNull(),
  price: doublePrecision("price").notNull(),
  totalSlots: integer("total_slots").notNull(),
  remainingSlots: integer("remaining_slots").notNull(),
  ownerId: integer("owner_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  isCompleted: boolean("is_completed").notNull().default(false),
});

// Task completions table
export const taskCompletions = pgTable("task_completions", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").notNull(),
  userId: integer("user_id").notNull(),
  textProof: text("text_proof"),
  imageProof: text("image_proof"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // deposit, withdrawal, task_credit, task_debit, referral_bonus
  amount: doublePrecision("amount").notNull(),
  status: text("status").notNull(), // pending, completed, rejected
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Deposits table
export const deposits = pgTable("deposits", {
  id: serial("id").primaryKey(),
  transactionId: integer("transaction_id").notNull(),
  userId: integer("user_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  paymentName: text("payment_name"),
  paymentReceipt: text("payment_receipt"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Withdrawals table
export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  transactionId: integer("transaction_id").notNull(),
  userId: integer("user_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  network: text("network").notNull(),
  phoneNumber: text("phone_number").notNull(),
  status: text("status").notNull().default("pending"), // pending, completed, rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  type: text("type").notNull(), // task_completion, task_approved, task_rejected, deposit, withdrawal, referral
  relatedId: integer("related_id"), // ID of the related entity (task, deposit, etc.)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Referrals table
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").notNull(),
  referredId: integer("referred_id").notNull(),
  bonus: doublePrecision("bonus").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
}).extend({
  password: z.string().min(6).max(100),
  referralCode: z.string().optional(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  name: true,
  description: true,
  link: true,
  price: true,
  totalSlots: true,
});

export const insertTaskCompletionSchema = createInsertSchema(taskCompletions).pick({
  taskId: true,
  textProof: true,
  imageProof: true,
});

export const insertDepositSchema = createInsertSchema(deposits).pick({
  amount: true,
  paymentName: true,
  paymentReceipt: true,
});

export const insertWithdrawalSchema = createInsertSchema(withdrawals).pick({
  amount: true,
  network: true,
  phoneNumber: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type TaskCompletion = typeof taskCompletions.$inferSelect;
export type InsertTaskCompletion = z.infer<typeof insertTaskCompletionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type Deposit = typeof deposits.$inferSelect;
export type InsertDeposit = z.infer<typeof insertDepositSchema>;
export type Withdrawal = typeof withdrawals.$inferSelect;
export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
export type Notification = typeof notifications.$inferSelect;
export type Referral = typeof referrals.$inferSelect;

// Generate unique referral code
export function generateReferralCode(): string {
  return `QR${nanoid(6).toUpperCase()}`;
}
