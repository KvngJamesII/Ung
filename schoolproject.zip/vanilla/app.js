
// Auth state
let isAuthenticated = false;
let currentUser = null;

// Mock data
const tasks = [
    { id: 1, title: 'Complete Survey', reward: 500, description: 'Fill out a brief survey about your shopping habits' },
    { id: 2, title: 'Watch Video', reward: 200, description: 'Watch a 2-minute video and provide feedback' },
    { id: 3, title: 'App Testing', reward: 1000, description: 'Test a new mobile app and report bugs' }
];

// UI Functions
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.style.display = 'block';
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

function renderTasks() {
    const tasksList = document.getElementById('tasksList');
    tasksList.innerHTML = tasks.map(task => `
        <div class="task-card">
            <h3>${task.title}</h3>
            <p>${task.description}</p>
            <p>Reward: ₦${task.reward}</p>
            <button onclick="startTask(${task.id})" class="btn-primary">Start Task</button>
        </div>
    `).join('');
}

function startTask(taskId) {
    if (!isAuthenticated) {
        showToast('Please login to start tasks');
        return;
    }
    const task = tasks.find(t => t.id === taskId);
    showToast(`Starting task: ${task.title}`);
}

function startEarning() {
    if (!isAuthenticated) {
        showToast('Please login to start earning');
        return;
    }
    document.getElementById('tasks').scrollIntoView({ behavior: 'smooth' });
}

function generateReferralCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function copyReferralCode() {
    const code = document.getElementById('referralCode').textContent;
    navigator.clipboard.writeText(code)
        .then(() => showToast('Referral code copied!'))
        .catch(() => showToast('Failed to copy code'));
}

// Auth Functions
function login() {
    // Mock login
    isAuthenticated = true;
    currentUser = { id: 1, name: 'Test User', referralCode: generateReferralCode() };
    updateUI();
    showToast('Logged in successfully');
}

function signup() {
    // Mock signup
    showToast('Account created successfully');
    login();
}

function updateUI() {
    const loginBtn = document.getElementById('loginBtn');
    const signupBtn = document.getElementById('signupBtn');
    const referralCode = document.getElementById('referralCode');

    if (isAuthenticated) {
        loginBtn.style.display = 'none';
        signupBtn.style.display = 'none';
        referralCode.textContent = currentUser.referralCode;
    }
}

// Event Listeners
document.getElementById('loginBtn').addEventListener('click', login);
document.getElementById('signupBtn').addEventListener('click', signup);

// Initialize
renderTasks();
updateUI();
